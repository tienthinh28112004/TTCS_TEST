package ApiWebManga.repository;

import ApiWebManga.Entity.BookElasticSearch;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookElasticRepository extends ElasticsearchRepository<BookElasticSearch,Long> {
    //JpaRepository được dùng để làm việc với cơ sở dữ liệu quan hệ(Mysql,postgreSQL,..)
    //ElasticsearchRepository được đùng dể làm việc với Elasticsearch,mội công cụ tìm kiếm mạnh mẽ dựa trên NoSQL
}
