package ApiWebManga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiWebMangaApplication {

	public static void main(String[] args) {

		SpringApplication.run(ApiWebMangaApplication.class, args);
	}

}
