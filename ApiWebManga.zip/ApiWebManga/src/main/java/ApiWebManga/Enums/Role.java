package ApiWebManga.Enums;

public enum Role {
    USER,ADMIN,MANAGER,STAFF
}
