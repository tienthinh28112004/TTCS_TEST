package ApiWebManga.Enums;

public enum PaymentExpression {
    ONLINEPAYMENT, DIRECTPAYMENT
}
