package ApiWebManga.Enums;

public enum OrderStatus {
    PENDING, COMPLETE, CANCELED,CONFIRMED,PROCESSING
}
